# Agent Pack Report

- Project: `AKR`
- Archive format: ZIP
- Compression: DEFLATE
- Final archive cap: 50.00 MB (decimal MB)
- Per-file cap: 5.00 MB (decimal MB)
- Files included in this pass: 298 (4.69 MB)
- Files removed to satisfy the archive cap: 0

## Included categories

- agent context: 63 files (563.39 kB)
- developer metadata: 10 files (68.06 kB)
- documentation: 54 files (989.02 kB)
- project code: 113 files (2.12 MB)
- root project metadata: 6 files (181.31 kB)
- tests/examples: 52 files (763.43 kB)

## Selection policy

The pack keeps original relative paths and file extensions. It includes recognized source-code, build/configuration, schema, shader, script, documentation, lock, test, and example files. `.akr`, `.claude`, and `.cargo` are the only hidden directories admitted and receive the highest retention priority. Other hidden directories, `target`, `build`, common generated-output/dependency directories, symlinks, binary build artifacts, archives/media/models, likely secret files, and files over the per-file cap are excluded.

## Scan exclusions

- Files visited: 439
- Oversized files: 1
- Build/binary artifacts: 2
- Possible secrets/private keys: 0
- Unsupported/non-development files: 112
- Binary-looking files with otherwise text-like extensions: 25
- Symlinks: 0
- Filesystem errors: 0

### Oversized examples

- `akr-gui.exe` — 10.30 MB > 5.00 MB

### Artifact examples

- `.akr/cache/index.sqlite` — build artifact or non-agent-readable binary asset
- `examples/save-your-skin/.akr/cache/index.sqlite` — build artifact or non-agent-readable binary asset
